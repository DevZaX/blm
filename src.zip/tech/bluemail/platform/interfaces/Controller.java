// 
// Decompiled by Procyon v0.5.36
// 

package tech.bluemail.platform.interfaces;

public interface Controller
{
    void start(final String[] p0) throws Exception;
}
